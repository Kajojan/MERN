// import { createSlice } from "@reduxjs/toolkit";
// import { action } from "./CalSlice";

// const AllcalSlice = createSlice({
//   name: "AllcalSlice",
//   initialState: {
//     Allcall: [],
//   },
//   // reducers: {
//     add: (state, action) => {
//       state.Allcall.push(action.payload)
//       console.log(state.Allcall, action.payload)
//     },
//     upload: (state, action) =>{
//       state.Allcall = action.payload
//     }
//   },
// });

// export const  {add, upload} = AllcalSlice.actions;

// export default AllcalSlice.reducer;
