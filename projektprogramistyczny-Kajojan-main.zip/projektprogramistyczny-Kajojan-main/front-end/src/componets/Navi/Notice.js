import React from "react";

function Notice() {
  return (
    <div>
      {" "}
      <button>Notice</button>
    </div>
  );
}

export default Notice;
